import { inputBaseClasses, outlinedInputClasses } from '@mui/material';

const OutlinedInput = {
  styleOverrides: {
    root: ({ theme }) => ({
      borderRadius: 8,
      ':hover': {
        [`&:not(&.${outlinedInputClasses.focused},.${outlinedInputClasses.disabled},.${outlinedInputClasses.error})`]:
          {
            [`& .${outlinedInputClasses.notchedOutline}`]: {
              borderColor: theme.vars.palette.action.disabled,
            },
          },
      },
      [`&.${outlinedInputClasses.disabled}`]: {
        [`& .${outlinedInputClasses.notchedOutline}`]: {
          borderColor: theme.vars.palette.divider,
        },
      },
      variants: [
        {
          props: { size: 'large' },
          style: {
            [`& .${outlinedInputClasses.input}`]: {
              padding: '12px 20px',
              fontSize: '16px',
            },
            [`& .${outlinedInputClasses.notchedOutline}`]: {
              padding: '0 14px',
            },
          },
        },
        {
          props: { size: 'small' },
          style: {
            borderRadius: 4,
          },
        },
      ],
      [`&.${inputBaseClasses.multiline}`]: {
        paddingLeft: 16,
        paddingRight: 16,
      },
    }),
    adornedStart: {
      paddingLeft: 16,
      [`&.${inputBaseClasses.sizeSmall}`]: {
        paddingLeft: 12,
      },
      [`&.MuiInputBase-sizeLarge`]: {
        paddingLeft: 20,
      },
      [`& .${outlinedInputClasses.input}`]: {
        paddingLeft: 0,
      },
    },
    input: () => ({
      padding: '8px 16px',
      paddingTop: '-2px !important',
      fontSize: 14,
      lineHeight: 1.5,
      boxSizing: 'border-box',
    }),
    sizeSmall: {
      borderRadius: 4,
      [`& .${outlinedInputClasses.notchedOutline}`]: {
        padding: '0 6px',
      },
    },
    inputAdornedStart: {
      paddingLeft: 0,
    },
    inputAdornedEnd: {
      paddingRight: 0,
    },
    inputSizeSmall: {
      padding: '8px 12px',
    },
    notchedOutline: ({ theme }) => ({
      borderStyle: 'solid',
      borderColor: theme.vars.palette.divider,
      borderWidth: '1px !important',
    }),
    multiline: {
      paddingTop: 13.5,
      paddingBottom: 13.5,
      paddingLeft: 11,
      paddingRight: 11,
      [`& .${outlinedInputClasses.input}`]: {
        padding: 0,
      },
    },
  },
};

export default OutlinedInput;
